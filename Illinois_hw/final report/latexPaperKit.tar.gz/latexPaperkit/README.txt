
To make a sample paper, copy the contents of this directory
somewhere, and type

 latex egpaper_final

or 

 pdflatex egpaper_final


